package practice.ch06.sec08.exam04;

public class Calculator {
    public double areaRectangle(double x) {
        return x * x;
    }
    public double areaRectangle(double x, double y) {
        return x * y;
    }
}
