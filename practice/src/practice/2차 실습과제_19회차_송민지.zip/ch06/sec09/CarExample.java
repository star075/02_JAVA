package practice.ch06.sec09;

public class CarExample {
    public static void main(String[] args) {
        Car car1 = new Car("현대자동차");
        car1.setSpeed(120);
        car1.run();
    }
}
